import { Curso } from './../curso.model';
import { Component, OnInit } from '@angular/core';
import { CursoService } from '../curso.service';

@Component({
  selector: 'app-cursos-listagem',
  templateUrl: './cursos-listagem.component.html',
  styleUrls: ['./cursos-listagem.component.css']
})
export class CursosListagemComponent implements OnInit {

 curso: Curso;
  submitted = false;

  constructor(private cursoService: CursoService) { }

  ngOnInit() {
    this.listar();
  }

  listar(){
    this.cursoService.getAll().subscribe(resp => {
     return this.curso = resp
    });
  }

  excluir(id){
    
    this.cursoService.delete(id).subscribe(resp => {
      console.log(resp);
      
      this.listar();
     });

  }

}
