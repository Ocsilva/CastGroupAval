import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { CadastroComponent } from './cadastro/cadastro.component';
import { AppRoutingModule } from './app.routing.module';
import { HttpClientModule } from '@angular/common/http';
import { CursoService } from './curso.service';
import { CursosListagemComponent } from './cursos-listagem/cursos-listagem.component';


@NgModule({
  declarations: [
    AppComponent,
    CadastroComponent,
    CursosListagemComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
  ],
  providers: [CursoService],
  bootstrap: [AppComponent]
})
export class AppModule { }
