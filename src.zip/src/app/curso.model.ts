export class Curso {
    
    categoria:any;

	descricaoAssunto:string;

	dataInicio:string;

	dataTermino:string;

	
}