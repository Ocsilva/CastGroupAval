import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Curso } from './curso.model';


@Injectable({
  providedIn: 'root'
})

export class CursoService {
  baseUrl = 'http://localhost:8080';

  id(id: any) {
    throw new Error("Method not implemented.");
    
  }

  constructor(private http: HttpClient) { }

  getAll(): Observable<Curso> {
    
    return this.http.get<Curso>(`${this.baseUrl}/curso`);
  }

  get(id): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  create(data): Observable<any> {
    return this.http.post(this.baseUrl, data);
  }

  update(id, data): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, data);
  }

  delete(id): Observable<any> {
    return this.http.delete(`${this.baseUrl}/curso/${id}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(this.baseUrl);
  }

  findByTitle(title): Observable<any> {
    return this.http.get(`${this.baseUrl}?title=${title}`);
  }
}
