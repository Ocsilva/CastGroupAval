package br.com.cast.avaliacao.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import br.com.cast.avaliacao.model.CursoModel;
import br.com.cast.avaliacao.repository.CursoRepository;

@Service
public class CursoService {

	@Autowired
	private CursoRepository cursoRepository;

	public List<CursoModel> findall() {
		return cursoRepository.findAll();
	}

	public Optional<CursoModel> findById(Integer id) {
		return cursoRepository.findById(id);
	}

	public CursoModel save(CursoModel cursoModel) {
		cursoModel.setId(null); // em jpa não salva id.
		cursoRepository.save(cursoModel);
		return cursoModel;
	}

	public CursoModel update(CursoModel cursoModel) {
		Optional<CursoModel> model = findById(cursoModel.getId());
		model.get().setDataInicio(cursoModel.getDataInicio());
		model.get().setDataTermino(cursoModel.getDataTermino());
		model.get().setDescricaoAssunto(cursoModel.getDescricaoAssunto());
		cursoRepository.save(model.get());
		return model.get();
	}

	public void delete(Integer id) {
		cursoRepository.deleteById(id);
	}
}
