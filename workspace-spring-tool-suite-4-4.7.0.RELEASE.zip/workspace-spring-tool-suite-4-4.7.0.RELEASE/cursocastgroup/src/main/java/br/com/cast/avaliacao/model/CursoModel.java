package br.com.cast.avaliacao.model;

import java.io.Serializable;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import br.com.cast.avaliacao.model.enums.Categoria;

@Entity // informa jpa que é uma classe de configuração model
@Table(name = "Curso")
public class CursoModel implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id // id da tabela
	@GeneratedValue(strategy = GenerationType.IDENTITY) // informa que é uma chave primária auto incrementada
	private Integer id;

	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name = "CATEGORIA")
	private Set<Integer> categoria = new HashSet<>();

	private String descricaoAssunto;

	private Calendar dataInicio;

	private Calendar dataTermino;

	public CursoModel() {

	}

	public CursoModel(Integer id, String descricaoAssunto, Calendar dataInicio, Calendar dataTermino) {

		this.id = id;
		this.descricaoAssunto = descricaoAssunto;
		this.dataInicio = dataInicio;
		this.dataTermino = dataTermino;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescricaoAssunto() {
		return descricaoAssunto;
	}

	public void setDescricaoAssunto(String descricaoAssunto) {
		this.descricaoAssunto = descricaoAssunto;
	}

	public Calendar getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Calendar dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Calendar getDataTermino() {
		return dataTermino;
	}

	public void setDataTermino(Calendar dataTermino) {
		this.dataTermino = dataTermino;
	}

	public Set<Categoria> getCategoria() {
		return categoria.stream().map(x -> Categoria.toEnum(x)).collect(Collectors.toSet());
	}

	public void addCategoria(Categoria categoria) {
		this.categoria.add(categoria.getCod());
	}

	@Override
	public String toString() {
		return "CursoModel [id=" + id + ", descricaoAssunto=" + descricaoAssunto + ", dataInicio=" + dataInicio
				+ ", dataTermino=" + dataTermino + "]";
	}

}
