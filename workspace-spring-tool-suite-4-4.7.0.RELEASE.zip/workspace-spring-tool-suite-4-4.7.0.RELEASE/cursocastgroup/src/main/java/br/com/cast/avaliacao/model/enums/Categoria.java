package br.com.cast.avaliacao.model.enums;

public enum Categoria {

	Comportamental(1, "Comportamental"), Programacao(2, "Programação"), Qualidade(3, "Qualidade"),
	Processos(4, "Processos");

	private int cod;
	private String descricao;

	private Categoria(int cod, String descricao) {
		this.cod = cod;
		this.descricao = descricao;
	}

	public int getCod() {
		return cod;
	}

	public String getDescricao() {
		return descricao;
	}

	public static Categoria toEnum(Integer cod) {

		if (cod == null) {
			return null;
		}

		for (Categoria x : Categoria.values()) {
			if (cod.equals(x.getCod())) {
				return x;
			}
		}
		throw new IllegalArgumentException("Id inválido: " + cod);
	}
}
