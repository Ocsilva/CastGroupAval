package br.com.cast.avaliacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursocastgroupApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursocastgroupApplication.class, args);
	}

}
