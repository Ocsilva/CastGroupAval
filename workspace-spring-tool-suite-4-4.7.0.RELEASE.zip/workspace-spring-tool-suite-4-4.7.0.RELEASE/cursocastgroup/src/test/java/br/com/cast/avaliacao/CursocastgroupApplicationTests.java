package br.com.cast.avaliacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursocastgroupApplicationTests {

	@Test
	void contextLoads() {
	}

}
